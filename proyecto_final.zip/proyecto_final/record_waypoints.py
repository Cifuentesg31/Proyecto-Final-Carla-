import csv
import math
import os
import sys
import time

PYTHON_CLIENT_PATH = r"C:\Coursera\CarlaSimulator\PythonClient"

if PYTHON_CLIENT_PATH not in sys.path:
    sys.path.append(PYTHON_CLIENT_PATH)

from carla.client import make_carla_client
from carla.settings import CarlaSettings

try:
    import pygame
except ImportError:
    raise RuntimeError(
        "No se pudo importar pygame. Instálalo con: py -3.6 -m pip install pygame --user"
    )


OUTPUT_FILE = "racetrack_waypoints.csv"


def save_waypoint(writer, step, x, y, z, yaw, speed):
    writer.writerow([
        step,
        "{:.4f}".format(x),
        "{:.4f}".format(y),
        "{:.4f}".format(z),
        "{:.4f}".format(yaw),
        "{:.4f}".format(speed)
    ])


def print_controls():
    print("\nControles:")
    print("  W  -> acelerar")
    print("  S  -> frenar")
    print("  A  -> girar izquierda")
    print("  D  -> girar derecha")
    print("  ESPACIO -> freno de mano")
    print("  Q  -> salir y guardar")
    print("\nConduce una vuelta completa por la pista.")
    print("El programa guardará waypoints en:", OUTPUT_FILE)
    print()


def main():
    host = "localhost"
    port = 2000

    pygame.init()
    pygame.display.set_mode((400, 200))
    pygame.display.set_caption("Grabador de waypoints - CARLA")

    print("Intentando conectar con CARLA...")

    with make_carla_client(host, port) as client:
        print("Conectado con CARLA.")

        settings = CarlaSettings()
        settings.set(
            SynchronousMode=True,
            SendNonPlayerAgentsInfo=False,
            NumberOfVehicles=0,
            NumberOfPedestrians=0,
            WeatherId=1
        )

        scene = client.load_settings(settings)

        print("Mapa cargado.")
        print("Cantidad de posiciones iniciales:", len(scene.player_start_spots))

        client.start_episode(0)

        print_controls()

        output_path = os.path.join(os.getcwd(), OUTPUT_FILE)

        csv_file = open(output_path, "w", newline="")
        writer = csv.writer(csv_file)

        writer.writerow([
            "step",
            "x",
            "y",
            "z",
            "yaw_deg",
            "speed_mps"
        ])

        step = 0
        running = True

        # Para no guardar demasiados puntos repetidos
        last_saved_x = None
        last_saved_y = None
        min_distance_between_points = 2.5  # metros

        throttle = 0.0
        brake = 0.0
        steer = 0.0
        hand_brake = False

        print("Grabación iniciada...\n")

        while running:
            pygame.event.pump()
            keys = pygame.key.get_pressed()

            if keys[pygame.K_q]:
                running = False

            # Acelerador y freno
            if keys[pygame.K_w]:
                throttle = 0.85
                brake = 0.0
            else:
                throttle = 0.0

            if keys[pygame.K_s]:
                brake = 0.7
                throttle = 0.0
            else:
                if not keys[pygame.K_w]:
                    brake = 0.0

            # Dirección
            steer = 0.0

            if keys[pygame.K_a]:
                steer = -0.35

            if keys[pygame.K_d]:
                steer = 0.35

            hand_brake = keys[pygame.K_SPACE]

            measurements, sensor_data = client.read_data()
            player = measurements.player_measurements

            x = player.transform.location.x
            y = player.transform.location.y
            z = player.transform.location.z
            yaw = player.transform.rotation.yaw
            speed = player.forward_speed

            should_save = False

            if last_saved_x is None or last_saved_y is None:
                should_save = True
            else:
                distance = math.hypot(x - last_saved_x, y - last_saved_y)

                if distance >= min_distance_between_points:
                    should_save = True

            if should_save:
                save_waypoint(
                    writer=writer,
                    step=step,
                    x=x,
                    y=y,
                    z=z,
                    yaw=yaw,
                    speed=speed
                )

                csv_file.flush()

                last_saved_x = x
                last_saved_y = y

                print(
                    "Waypoint {:04d} | x={:.2f}, y={:.2f}, yaw={:.2f}°, v={:.2f} m/s".format(
                        step,
                        x,
                        y,
                        yaw,
                        speed
                    )
                )

            client.send_control(
                steer=steer,
                throttle=throttle,
                brake=brake,
                hand_brake=hand_brake,
                reverse=False
            )

            step += 1
            time.sleep(0.05)

        client.send_control(
            steer=0.0,
            throttle=0.0,
            brake=1.0,
            hand_brake=False,
            reverse=False
        )

        csv_file.close()

        print("\nGrabación finalizada.")
        print("Archivo guardado en:")
        print(output_path)

    pygame.quit()


if __name__ == "__main__":
    main()