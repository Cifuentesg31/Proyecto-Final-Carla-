# -*- coding: utf-8 -*-
"""
Created on Mon May 25 18:05:25 2026

@author: camic
"""

import csv


INPUT_FILE = "racetrack_waypoints.csv"
OUTPUT_FILE = "racetrack_waypoints_trimmed.csv"

# Índice encontrado por find_lap_closure.py
CLOSURE_INDEX = 1590


def main():
    rows = []

    with open(INPUT_FILE, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            rows.append(row)

    trimmed_rows = rows[:CLOSURE_INDEX + 1]

    with open(OUTPUT_FILE, "w", newline="") as file:
        fieldnames = ["step", "x", "y", "z", "yaw_deg", "speed_mps"]
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        writer.writeheader()

        for row in trimmed_rows:
            writer.writerow(row)

    print("Archivo original:", INPUT_FILE)
    print("Waypoints originales:", len(rows))
    print("Archivo recortado:", OUTPUT_FILE)
    print("Waypoints recortados:", len(trimmed_rows))
    print("Último índice usado:", CLOSURE_INDEX)


if __name__ == "__main__":
    main()