import csv
import math


WAYPOINT_FILE = "racetrack_waypoints_trimmed.csv"

def load_waypoints(filename):
    waypoints = []

    with open(filename, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            x = float(row["x"])
            y = float(row["y"])
            z = float(row["z"])
            yaw = float(row["yaw_deg"])
            speed = float(row["speed_mps"])

            waypoints.append((x, y, z, yaw, speed))

    return waypoints


def analyze_waypoints(waypoints):
    total_distance = 0.0
    max_gap = 0.0
    max_gap_index = 0

    for i in range(1, len(waypoints)):
        x1, y1, _, _, _ = waypoints[i - 1]
        x2, y2, _, _, _ = waypoints[i]

        distance = math.hypot(x2 - x1, y2 - y1)
        total_distance += distance

        if distance > max_gap:
            max_gap = distance
            max_gap_index = i

    first_x, first_y, _, first_yaw, _ = waypoints[0]
    last_x, last_y, _, last_yaw, _ = waypoints[-1]

    closing_distance = math.hypot(last_x - first_x, last_y - first_y)

    print("Análisis de waypoints")
    print("---------------------")
    print("Cantidad de waypoints:", len(waypoints))
    print("Distancia total aproximada: {:.2f} m".format(total_distance))
    print("Mayor salto entre puntos: {:.2f} m".format(max_gap))
    print("Índice del mayor salto:", max_gap_index)
    print("Distancia entre inicio y final: {:.2f} m".format(closing_distance))

    print("\nPrimer waypoint:")
    print("x={:.2f}, y={:.2f}, yaw={:.2f}°".format(first_x, first_y, first_yaw))

    print("\nÚltimo waypoint:")
    print("x={:.2f}, y={:.2f}, yaw={:.2f}°".format(last_x, last_y, last_yaw))

    if closing_distance < 10.0:
        print("\nResultado: La trayectoria parece cerrada.")
    else:
        print("\nAdvertencia: La trayectoria NO parece cerrar bien.")

    if max_gap < 5.0:
        print("Resultado: No se ven saltos grandes entre puntos.")
    else:
        print("Advertencia: Hay un salto grande entre waypoints.")


def main():
    waypoints = load_waypoints(WAYPOINT_FILE)

    if len(waypoints) == 0:
        print("No se cargaron waypoints.")
        return

    analyze_waypoints(waypoints)


if __name__ == "__main__":
    main()