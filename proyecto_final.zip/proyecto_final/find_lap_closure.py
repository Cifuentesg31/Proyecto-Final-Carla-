# -*- coding: utf-8 -*-
"""
Created on Mon May 25 18:03:49 2026

@author: camic
"""

import csv
import math


WAYPOINT_FILE = "racetrack_waypoints.csv"


def load_waypoints(filename):
    waypoints = []

    with open(filename, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            x = float(row["x"])
            y = float(row["y"])
            yaw = float(row["yaw_deg"])
            speed = float(row["speed_mps"])

            waypoints.append((x, y, yaw, speed))

    return waypoints


def main():
    waypoints = load_waypoints(WAYPOINT_FILE)

    if len(waypoints) < 10:
        print("Hay muy pocos waypoints.")
        return

    start_x, start_y, start_yaw, _ = waypoints[0]

    # Ignoramos los primeros puntos para no detectar el inicio inmediatamente.
    # Puedes ajustar este valor si hace falta.
    ignore_first_points = 100

    best_index = None
    best_distance = float("inf")

    for i in range(ignore_first_points, len(waypoints)):
        x, y, yaw, speed = waypoints[i]
        distance_to_start = math.hypot(x - start_x, y - start_y)

        if distance_to_start < best_distance:
            best_distance = distance_to_start
            best_index = i

    print("Búsqueda de cierre de vuelta")
    print("---------------------------")
    print("Cantidad de waypoints:", len(waypoints))
    print("Punto inicial: x={:.2f}, y={:.2f}".format(start_x, start_y))
    print("Punto más cercano al inicio después del arranque:")
    print("Índice:", best_index)

    x, y, yaw, speed = waypoints[best_index]

    print("x={:.2f}, y={:.2f}, yaw={:.2f}°, v={:.2f} m/s".format(
        x,
        y,
        yaw,
        speed
    ))
    print("Distancia al inicio: {:.2f} m".format(best_distance))

    if best_distance < 5.0:
        print("\nResultado: Sí parece que completaste la vuelta.")
        print("Recomendación: recortar la trayectoria hasta el índice", best_index)
    elif best_distance < 10.0:
        print("\nResultado: La vuelta probablemente cerró, pero no de forma perfecta.")
        print("Recomendación: se puede usar, aunque conviene revisar.")
    else:
        print("\nResultado: No se encontró un cierre claro cerca del inicio.")


if __name__ == "__main__":
    main()