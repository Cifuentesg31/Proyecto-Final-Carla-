import csv
import math
import os
import sys
import time


# ============================================================
# CONFIGURACIÓN PORTABLE DE CARLA
# ============================================================
# Este bloque evita dejar una ruta fija como:
# C:\Coursera\CarlaSimulator\PythonClient
#
# Formas válidas de usarlo en otro PC:
#
# 1. Si el módulo carla ya está instalado o disponible en Python,
#    no tienes que hacer nada.
#
# 2. Si CARLA está en una carpeta específica, puedes definir una
#    variable de entorno llamada CARLA_PYTHON_CLIENT.
#
#    Windows CMD:
#    set CARLA_PYTHON_CLIENT=C:\Coursera\CarlaSimulator\PythonClient
#
#    Ubuntu:
#    export CARLA_PYTHON_CLIENT=/home/usuario/CarlaSimulator/PythonClient
#
# 3. Si no defines nada, el script intenta buscar PythonClient
#    en carpetas cercanas al proyecto.
# ============================================================

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

possible_carla_paths = [
    os.environ.get("CARLA_PYTHON_CLIENT"),
    os.path.join(SCRIPT_DIR, "PythonClient"),
    os.path.join(SCRIPT_DIR, "..", "PythonClient"),
    os.path.join(SCRIPT_DIR, "..", "..", "PythonClient"),
    os.path.join(os.getcwd(), "PythonClient"),
    os.path.join(os.getcwd(), "..", "PythonClient"),
]

for carla_path in possible_carla_paths:
    if carla_path and os.path.isdir(carla_path):
        carla_path = os.path.abspath(carla_path)

        if carla_path not in sys.path:
            sys.path.append(carla_path)

try:
    from carla.client import make_carla_client
    from carla.settings import CarlaSettings
except ImportError:
    print("ERROR: No se pudo importar la API de Python de CARLA.")
    print("")
    print("Soluciones:")
    print("1. Verifica que CARLA esté instalado.")
    print("2. Verifica que exista la carpeta PythonClient de CARLA.")
    print("3. Define la variable de entorno CARLA_PYTHON_CLIENT.")
    print("")
    print("Ejemplo Windows:")
    print(r"set CARLA_PYTHON_CLIENT=C:\Coursera\CarlaSimulator\PythonClient")
    print("")
    print("Ejemplo Ubuntu:")
    print("export CARLA_PYTHON_CLIENT=/home/usuario/CarlaSimulator/PythonClient")
    print("")
    raise


# ============================================================
# ARCHIVO DE WAYPOINTS
# ============================================================

WAYPOINT_FILE = "racetrack_waypoints_trimmed.csv"


# ============================================================
# FUNCIONES AUXILIARES
# ============================================================

def normalize_angle(angle):
    while angle > math.pi:
        angle -= 2.0 * math.pi

    while angle < -math.pi:
        angle += 2.0 * math.pi

    return angle


def load_waypoints(filename):
    """
    Carga los waypoints desde el CSV.
    El archivo debe estar en la misma carpeta que este script.
    """

    path = []

    waypoint_path = os.path.join(SCRIPT_DIR, filename)

    if not os.path.exists(waypoint_path):
        raise FileNotFoundError(
            "No se encontró el archivo de waypoints: {}".format(waypoint_path)
        )

    with open(waypoint_path, "r") as file:
        reader = csv.DictReader(file)

        for row in reader:
            x = float(row["x"])
            y = float(row["y"])
            path.append((x, y))

    return path


def get_path_point(path, index):
    """
    Permite leer la trayectoria como circular.
    Si el índice supera el final, vuelve al inicio con módulo.
    """

    path_length = len(path)
    real_index = index % path_length

    return path[real_index]


def find_global_nearest_index(vehicle_x, vehicle_y, path):
    """
    Busca el waypoint más cercano en toda la trayectoria.

    Esta función solo se usa una vez al inicio para detectar
    desde qué punto de la ruta debe comenzar la vuelta.
    """

    nearest_index = 0
    nearest_distance = float("inf")

    for i, point in enumerate(path):
        px, py = point
        distance = math.hypot(px - vehicle_x, py - vehicle_y)

        if distance < nearest_distance:
            nearest_distance = distance
            nearest_index = i

    return nearest_index, nearest_distance


def find_nearest_point_forward_circular(
    vehicle_x,
    vehicle_y,
    path,
    last_progress_index,
    search_window=380
):
    """
    Busca el waypoint más cercano solo hacia adelante desde el último índice.

    Esto evita saltos falsos hacia otra zona de la pista.
    """

    nearest_progress_index = last_progress_index
    nearest_distance = float("inf")

    start_index = last_progress_index
    end_index = last_progress_index + search_window

    for progress_index in range(start_index, end_index + 1):
        px, py = get_path_point(path, progress_index)
        distance = math.hypot(px - vehicle_x, py - vehicle_y)

        if distance < nearest_distance:
            nearest_distance = distance
            nearest_progress_index = progress_index

    return nearest_progress_index, nearest_distance


def find_target_point_forward_circular(
    vehicle_x,
    vehicle_y,
    path,
    lookahead_distance,
    last_progress_index
):
    """
    Busca el punto objetivo hacia adelante.

    Se usa índice progresivo circular para permitir iniciar desde
    cualquier punto de la pista y completar una vuelta completa.
    """

    nearest_progress_index, nearest_distance = find_nearest_point_forward_circular(
        vehicle_x=vehicle_x,
        vehicle_y=vehicle_y,
        path=path,
        last_progress_index=last_progress_index,
        search_window=380
    )

    target_progress_index = nearest_progress_index + 450

    for progress_index in range(nearest_progress_index + 1, nearest_progress_index + 451):
        px, py = get_path_point(path, progress_index)
        distance = math.hypot(px - vehicle_x, py - vehicle_y)

        if distance >= lookahead_distance:
            target_progress_index = progress_index
            break

    target_x, target_y = get_path_point(path, target_progress_index)

    return (
        target_x,
        target_y,
        target_progress_index,
        nearest_progress_index,
        nearest_distance
    )


# ============================================================
# CONTROL LATERAL: PURE PURSUIT
# ============================================================

def calculate_pure_pursuit_steering(
    vehicle_x,
    vehicle_y,
    vehicle_yaw_rad,
    vehicle_speed,
    path,
    last_progress_index,
    wheelbase=2.875,
    lookahead_gain=1.85,
    min_lookahead=12.0,
    max_steer_angle_deg=70.0
):
    """
    Calcula el ángulo de dirección usando Pure Pursuit.

    Como esta versión es más rápida, usa un lookahead mayor para
    mirar más adelante y suavizar la dirección.
    """

    lookahead_distance = max(
        lookahead_gain * abs(vehicle_speed),
        min_lookahead
    )

    (
        target_x,
        target_y,
        target_progress_index,
        nearest_progress_index,
        nearest_distance
    ) = find_target_point_forward_circular(
        vehicle_x=vehicle_x,
        vehicle_y=vehicle_y,
        path=path,
        lookahead_distance=lookahead_distance,
        last_progress_index=last_progress_index
    )

    angle_to_target = math.atan2(
        target_y - vehicle_y,
        target_x - vehicle_x
    )

    alpha = normalize_angle(angle_to_target - vehicle_yaw_rad)

    delta = math.atan2(
        2.0 * wheelbase * math.sin(alpha),
        lookahead_distance
    )

    max_steer_angle_rad = math.radians(max_steer_angle_deg)

    steer = delta / max_steer_angle_rad
    steer = max(-1.0, min(1.0, steer))

    return {
        "steer": steer,
        "delta_rad": delta,
        "alpha_rad": alpha,
        "target_x": target_x,
        "target_y": target_y,
        "target_progress_index": target_progress_index,
        "nearest_progress_index": nearest_progress_index,
        "nearest_index_real": nearest_progress_index % len(path),
        "target_index_real": target_progress_index % len(path),
        "nearest_distance": nearest_distance,
        "lookahead_distance": lookahead_distance
    }


# ============================================================
# CONTROL LONGITUDINAL
# ============================================================

def longitudinal_control(target_speed, current_speed):
    """
    Control longitudinal rápido.

    Esta versión acelera más para intentar alcanzar velocidades altas,
    pero sigue usando freno si se excede demasiado.
    """

    error = target_speed - current_speed

    if error > 3.0:
        throttle = 1.00
        brake = 0.0

    elif error > 1.5:
        throttle = 0.98
        brake = 0.0

    elif error > 0.5:
        throttle = 0.88
        brake = 0.0

    elif error < -3.0:
        throttle = 0.0
        brake = 0.42

    elif error < -1.2:
        throttle = 0.0
        brake = 0.22

    else:
        throttle = 0.62
        brake = 0.0

    return throttle, brake


def calculate_target_speed(nearest_distance):
    """
    Velocidad adaptativa alta.

    Máximo: 18 m/s, aproximadamente 64.8 km/h.

    Si el error lateral crece, baja automáticamente la velocidad.
    """

    if nearest_distance > 8.0:
        return 5.0

    if nearest_distance > 6.0:
        return 8.0

    if nearest_distance > 4.0:
        return 11.0

    if nearest_distance > 2.8:
        return 14.0

    return 18.0


def smooth_value(previous_value, new_value, max_change):
    """
    Limita cambios bruscos en dirección, acelerador y freno.
    """

    difference = new_value - previous_value

    if difference > max_change:
        return previous_value + max_change

    if difference < -max_change:
        return previous_value - max_change

    return new_value


# ============================================================
# PROGRAMA PRINCIPAL
# ============================================================

def main():
    host = "localhost"
    port = 2000

    path = load_waypoints(WAYPOINT_FILE)

    if len(path) < 20:
        print("Error: hay muy pocos waypoints.")
        return

    path_length = len(path)

    print("Waypoints cargados:", path_length)
    print("Archivo:", os.path.join(SCRIPT_DIR, WAYPOINT_FILE))

    print("\nIntentando conectar con CARLA...")

    with make_carla_client(host, port) as client:
        print("Conectado con CARLA.")

        settings = CarlaSettings()
        settings.set(
            SynchronousMode=True,
            SendNonPlayerAgentsInfo=False,
            NumberOfVehicles=0,
            NumberOfPedestrians=0,
            WeatherId=1
        )

        scene = client.load_settings(settings)

        print("Mapa cargado.")
        print("Cantidad de posiciones iniciales:", len(scene.player_start_spots))

        client.start_episode(0)

        print("\nControl automático iniciado.")
        print("VERSIÓN PORTABLE Y MÁS RÁPIDA:")
        print("- No usa ruta absoluta fija a tu PC.")
        print("- Detecta el waypoint inicial automáticamente.")
        print("- Recorre una vuelta completa desde el punto inicial.")
        print("- Usa índice progresivo circular para evitar saltos falsos.")
        print("- Velocidad máxima objetivo: 18.0 m/s aprox. 64.8 km/h.")
        print("- Si se vuelve inestable, baja la velocidad máxima a 15.0 o 13.0 m/s.\n")

        total_steps = 30000

        previous_steer = 0.0
        previous_throttle = 0.0
        previous_brake = 0.0

        max_steer_change = 0.050
        max_throttle_change = 0.150
        max_brake_change = 0.140

        start_time = time.time()

        # Leer una primera medición para detectar dónde apareció el carro.
        measurements, sensor_data = client.read_data()
        player = measurements.player_measurements

        start_x = player.transform.location.x
        start_y = player.transform.location.y

        start_index, start_distance = find_global_nearest_index(
            vehicle_x=start_x,
            vehicle_y=start_y,
            path=path
        )

        last_progress_index = start_index

        # El final será una vuelta completa después del índice inicial.
        finish_progress_index = start_index + path_length - 3

        print("Índice inicial detectado:", start_index)
        print("Distancia inicial a la ruta: {:.2f} m".format(start_distance))
        print("Índice final objetivo:", finish_progress_index)
        print("Esto equivale a completar una vuelta desde el punto de arranque.\n")

        lap_finished = False

        for step in range(total_steps):
            measurements, sensor_data = client.read_data()
            player = measurements.player_measurements

            x = player.transform.location.x
            y = player.transform.location.y
            yaw_deg = player.transform.rotation.yaw
            yaw_rad = math.radians(yaw_deg)
            speed = player.forward_speed

            lateral_data = calculate_pure_pursuit_steering(
                vehicle_x=x,
                vehicle_y=y,
                vehicle_yaw_rad=yaw_rad,
                vehicle_speed=speed,
                path=path,
                last_progress_index=last_progress_index,
                wheelbase=2.875,
                lookahead_gain=1.85,
                min_lookahead=12.0,
                max_steer_angle_deg=70.0
            )

            nearest_progress_candidate = lateral_data["nearest_progress_index"]
            target_progress_index = lateral_data["target_progress_index"]
            nearest_distance = lateral_data["nearest_distance"]

            # El índice progresivo nunca puede retroceder.
            if nearest_progress_candidate < last_progress_index:
                nearest_progress_candidate = last_progress_index

            progress_jump = nearest_progress_candidate - last_progress_index

            # Bloqueo de saltos grandes.
            if progress_jump > 150:
                print("\nALERTA: intento de salto bloqueado.")
                print("Paso:", step)
                print("Índice anterior:", last_progress_index)
                print("Índice candidato:", nearest_progress_candidate)
                print("Salto:", progress_jump)
                print("Se limita el avance a 150 índices.\n")

                nearest_progress_candidate = last_progress_index + 150

            last_progress_index = nearest_progress_candidate

            target_speed = calculate_target_speed(nearest_distance)

            throttle, brake = longitudinal_control(
                target_speed=target_speed,
                current_speed=speed
            )

            steer = lateral_data["steer"]

            steer = smooth_value(previous_steer, steer, max_steer_change)
            throttle = smooth_value(previous_throttle, throttle, max_throttle_change)
            brake = smooth_value(previous_brake, brake, max_brake_change)

            previous_steer = steer
            previous_throttle = throttle
            previous_brake = brake

            if last_progress_index >= finish_progress_index and step > 300:
                lap_finished = True
                throttle = 0.0
                brake = 1.0
                steer = 0.0

            client.send_control(
                steer=steer,
                throttle=throttle,
                brake=brake,
                hand_brake=False,
                reverse=False
            )

            if step % 50 == 0:
                elapsed_time = time.time() - start_time

                progress_lap = 100.0 * (
                    last_progress_index - start_index
                ) / float(path_length)

                print(
                    "Paso {:05d} | "
                    "t={:.1f}s | "
                    "vuelta={:.1f}% | "
                    "v={:.2f} m/s, v_obj={:.2f}, "
                    "steer={:.3f}, throttle={:.3f}, brake={:.3f}, "
                    "idx_real={}, idx_prog={}, target_real={}, "
                    "error_lat={:.2f}, avance={}".format(
                        step,
                        elapsed_time,
                        progress_lap,
                        speed,
                        target_speed,
                        steer,
                        throttle,
                        brake,
                        last_progress_index % path_length,
                        last_progress_index,
                        target_progress_index % path_length,
                        nearest_distance,
                        progress_jump
                    )
                )

            if lap_finished:
                print("\nVuelta completa finalizada desde el punto de arranque.")
                break

            time.sleep(0.003)

        final_time = time.time() - start_time

        client.send_control(
            steer=0.0,
            throttle=0.0,
            brake=1.0,
            hand_brake=False,
            reverse=False
        )

        print("\nPrueba finalizada.")
        print("Tiempo aproximado: {:.2f} s".format(final_time))
        print("Índice inicial:", start_index)
        print("Índice progresivo final:", last_progress_index)
        print("Índice final objetivo:", finish_progress_index)
        print("Total de waypoints:", path_length)

        if last_progress_index >= finish_progress_index:
            print("Resultado: vuelta completada correctamente desde el punto inicial detectado.")
        else:
            print("Advertencia: no completó la vuelta.")
            print("Puede haberse quedado físicamente trabado, el error lateral pudo crecer demasiado o la velocidad es demasiado alta.")


if __name__ == "__main__":
    main()